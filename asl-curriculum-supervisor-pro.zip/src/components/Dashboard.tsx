import { Attendee, CurriculumWeek, HomeworkResponse, Semester } from '../types';
import { motion } from 'motion/react';
import { ChevronUp, ChevronDown, Award, Calendar, BookOpen } from 'lucide-react';

interface DashboardProps {
  attendees: Attendee[];
  curriculum: CurriculumWeek[];
  homework: HomeworkResponse[];
  onRefresh: () => void;
  selectedSemester: Semester;
}

export default function Dashboard({ attendees, curriculum, homework, onRefresh, selectedSemester }: DashboardProps) {
  const currentWeek = curriculum.find(w => w.weekNumber === 1 && w.semester === selectedSemester) || curriculum[0]; // Simplified logic
  const pendingHomework = homework.filter(h => !h.feedback).length;

  const moveRank = async (id: string, direction: 'up' | 'down') => {
    const index = attendees.findIndex(a => a.id === id);
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === attendees.length - 1) return;

    const newAttendees = [...attendees];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    [newAttendees[index], newAttendees[targetIndex]] = [newAttendees[targetIndex], newAttendees[index]];

    const ranks = newAttendees.map((a, i) => ({ id: a.id, rank: i + 1 }));
    
    await fetch('/api/attendees/rank', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ranks }),
    });
    onRefresh();
  };

  return (
    <div className="space-y-8">
      <header>
        <h2 className="text-3xl font-bold tracking-tight text-stone-900">Dashboard</h2>
        <p className="text-stone-500 mt-1">Overview of the current curriculum progress and attendee rankings.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Stats Cards */}
        <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-stone-100 rounded-2xl text-stone-600">
              <Calendar size={24} />
            </div>
            <div>
              <div className="text-xs font-mono text-stone-400 uppercase tracking-wider">Current Week</div>
              <div className="text-2xl font-bold">Week {currentWeek?.weekNumber || 1}</div>
            </div>
          </div>
          <div className="text-sm text-stone-500">{currentWeek?.semester} Semester</div>
        </div>

        <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-stone-100 rounded-2xl text-stone-600">
              <BookOpen size={24} />
            </div>
            <div>
              <div className="text-xs font-mono text-stone-400 uppercase tracking-wider">Active Topic</div>
              <div className="text-lg font-bold truncate max-w-[180px]">{currentWeek?.bookTopic}</div>
            </div>
          </div>
          <div className="text-sm text-stone-500">Job: {currentWeek?.jobTopic}</div>
        </div>

        <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-stone-100 rounded-2xl text-stone-600">
              <Award size={24} />
            </div>
            <div>
              <div className="text-xs font-mono text-stone-400 uppercase tracking-wider">Pending Feedback</div>
              <div className="text-2xl font-bold">{pendingHomework}</div>
            </div>
          </div>
          <div className="text-sm text-stone-500">Assignments to review</div>
        </div>
      </div>

      {/* Ranking System */}
      <section className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
        <div className="p-6 border-bottom border-stone-100 flex justify-between items-center">
          <h3 className="font-bold text-lg">Attendee Rankings</h3>
          <span className="text-xs font-mono text-stone-400 uppercase tracking-widest">Performance Based</span>
        </div>
        <div className="divide-y divide-stone-100">
          {attendees.map((attendee, index) => (
            <motion.div
              layout
              key={attendee.id}
              className="p-4 flex items-center gap-6 hover:bg-stone-50 transition-colors"
            >
              <div className="w-8 text-center font-mono text-stone-300 font-bold text-xl">
                {index + 1}
              </div>
              <div className="flex-1">
                <div className="font-bold text-stone-900">{attendee.name}</div>
                <div className="text-xs text-stone-500">{attendee.storeLocation} • {attendee.tenure}</div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-32 h-2 bg-stone-100 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${attendee.progress}%` }}
                    className="h-full bg-stone-900"
                  />
                </div>
                <div className="text-xs font-mono font-bold w-8">{attendee.progress}%</div>
              </div>
              <div className="flex flex-col gap-1">
                <button
                  onClick={() => moveRank(attendee.id, 'up')}
                  disabled={index === 0}
                  className="p-1 hover:bg-stone-200 rounded transition-colors disabled:opacity-20"
                >
                  <ChevronUp size={16} />
                </button>
                <button
                  onClick={() => moveRank(attendee.id, 'down')}
                  disabled={index === attendees.length - 1}
                  className="p-1 hover:bg-stone-200 rounded transition-colors disabled:opacity-20"
                >
                  <ChevronDown size={16} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
