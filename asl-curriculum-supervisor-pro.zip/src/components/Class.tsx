import { useState } from 'react';
import { Attendee } from '../types';
import { STORE_LOCATIONS } from '../constants';
import { motion } from 'motion/react';
import { UserPlus, MapPin, Clock, BarChart3, Search } from 'lucide-react';

interface ClassProps {
  attendees: Attendee[];
  onRefresh: () => void;
}

export default function Class({ attendees, onRefresh }: ClassProps) {
  const [showAdd, setShowAdd] = useState(false);
  const [newAttendee, setNewAttendee] = useState<Partial<Attendee>>({
    storeLocation: STORE_LOCATIONS[0],
    progress: 0,
    tenure: 'New'
  });
  const [search, setSearch] = useState('');

  const filteredAttendees = attendees.filter(a => 
    a.name.toLowerCase().includes(search.toLowerCase()) || 
    a.storeLocation.toLowerCase().includes(search.toLowerCase())
  );

  const locationStats = STORE_LOCATIONS.map(loc => ({
    name: loc,
    count: attendees.filter(a => a.storeLocation === loc).length
  })).filter(s => s.count > 0);

  const handleAdd = async () => {
    if (!newAttendee.name) return;
    await fetch('/api/attendees', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        ...newAttendee, 
        id: Date.now().toString(),
        rank: attendees.length + 1
      }),
    });
    setNewAttendee({ storeLocation: STORE_LOCATIONS[0], progress: 0, tenure: 'New' });
    setShowAdd(false);
    onRefresh();
  };

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-stone-900">Class Roster</h2>
          <p className="text-stone-500 mt-1">Manage attendees, track their tenure, and monitor distribution across the store.</p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 px-6 py-3 bg-stone-900 text-white rounded-2xl text-sm font-bold hover:bg-stone-800 transition-all shadow-lg shadow-stone-200"
        >
          <UserPlus size={18} /> Add Attendee
        </button>
      </header>

      {/* Stats Section */}
      <section className="p-8 bg-white rounded-[32px] border border-stone-200 shadow-sm">
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2 bg-stone-100 rounded-xl text-stone-600">
            <BarChart3 size={20} />
          </div>
          <h3 className="text-xl font-bold">Location Distribution</h3>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {locationStats.map((stat) => (
            <div key={stat.name} className="space-y-2">
              <div className="text-[10px] font-mono text-stone-400 uppercase tracking-wider truncate">{stat.name}</div>
              <div className="flex items-end gap-2">
                <div className="text-3xl font-bold">{stat.count}</div>
                <div className="text-xs text-stone-400 mb-1">Staff</div>
              </div>
              <div className="w-full h-1 bg-stone-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-stone-900" 
                  style={{ width: `${(stat.count / attendees.length) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Roster Section */}
      <section className="space-y-4">
        <div className="relative">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            className="w-full p-4 pl-12 bg-white border border-stone-200 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-stone-900/10 shadow-sm"
            placeholder="Search by name or location..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAttendees.map((attendee) => (
            <motion.div
              layout
              key={attendee.id}
              className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm hover:border-stone-400 transition-all"
            >
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h4 className="font-bold text-lg text-stone-900">{attendee.name}</h4>
                  <div className="flex items-center gap-1 text-xs text-stone-500 mt-1">
                    <MapPin size={12} /> {attendee.storeLocation}
                  </div>
                </div>
                <div className="w-12 h-12 bg-stone-100 rounded-2xl flex items-center justify-center text-stone-400 font-mono text-xs">
                  #{attendee.rank}
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center text-sm">
                  <div className="flex items-center gap-2 text-stone-500">
                    <Clock size={14} /> Tenure
                  </div>
                  <span className="font-medium">{attendee.tenure}</span>
                </div>
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[10px] font-mono text-stone-400 uppercase tracking-wider">
                    <span>Progress</span>
                    <span>{attendee.progress}%</span>
                  </div>
                  <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${attendee.progress}%` }}
                      className="h-full bg-stone-900"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Add Attendee Modal */}
      {showAdd && (
        <div className="fixed inset-0 bg-stone-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white w-full max-w-md rounded-[32px] shadow-2xl p-8 space-y-6"
          >
            <h3 className="text-2xl font-bold">Add New Attendee</h3>
            
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-mono text-stone-400 uppercase tracking-wider mb-1 block">Full Name</label>
                <input
                  type="text"
                  className="w-full p-4 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-stone-900/10"
                  placeholder="e.g., Jane Doe"
                  value={newAttendee.name || ''}
                  onChange={(e) => setNewAttendee({ ...newAttendee, name: e.target.value })}
                />
              </div>

              <div>
                <label className="text-[10px] font-mono text-stone-400 uppercase tracking-wider mb-1 block">Store Location</label>
                <select
                  className="w-full p-4 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-stone-900/10 appearance-none"
                  value={newAttendee.storeLocation}
                  onChange={(e) => setNewAttendee({ ...newAttendee, storeLocation: e.target.value })}
                >
                  {STORE_LOCATIONS.map(loc => (
                    <option key={loc} value={loc}>{loc}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] font-mono text-stone-400 uppercase tracking-wider mb-1 block">Tenure</label>
                <input
                  type="text"
                  className="w-full p-4 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-stone-900/10"
                  placeholder="e.g., 6 months"
                  value={newAttendee.tenure || ''}
                  onChange={(e) => setNewAttendee({ ...newAttendee, tenure: e.target.value })}
                />
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                onClick={() => setShowAdd(false)}
                className="flex-1 py-4 bg-stone-100 text-stone-600 rounded-2xl font-bold hover:bg-stone-200 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleAdd}
                className="flex-1 py-4 bg-stone-900 text-white rounded-2xl font-bold hover:bg-stone-800 transition-all shadow-lg shadow-stone-200"
              >
                Add Attendee
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
