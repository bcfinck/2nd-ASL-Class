import { useState } from 'react';
import { ReferenceMaterial } from '../types';
import { motion } from 'motion/react';
import { Book, Briefcase, Plus, ExternalLink, FileText, Link as LinkIcon } from 'lucide-react';

interface ReferenceProps {
  materials: ReferenceMaterial[];
  onRefresh: () => void;
}

export default function ReferenceMaterials({ materials, onRefresh }: ReferenceProps) {
  const [showAdd, setShowAdd] = useState(false);
  const [newMaterial, setNewMaterial] = useState<Partial<ReferenceMaterial>>({ type: 'book' });

  const books = materials.filter(m => m.type === 'book');
  const jobs = materials.filter(m => m.type === 'job');

  const handleAdd = async () => {
    if (!newMaterial.title || !newMaterial.link) return;
    await fetch('/api/reference-materials', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...newMaterial, id: Date.now().toString() }),
    });
    setNewMaterial({ type: 'book' });
    setShowAdd(false);
    onRefresh();
  };

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-stone-900">Reference Materials</h2>
          <p className="text-stone-500 mt-1">Centralized repository for curriculum books and job-specific resources.</p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 px-6 py-3 bg-stone-900 text-white rounded-2xl text-sm font-bold hover:bg-stone-800 transition-all shadow-lg shadow-stone-200"
        >
          <Plus size={18} /> Add Material
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Book References */}
        <section className="space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-stone-100">
            <div className="p-2 bg-stone-100 rounded-xl text-stone-600">
              <Book size={20} />
            </div>
            <h3 className="text-xl font-bold">Book References</h3>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {books.map((m) => (
              <div key={m.id} className="p-5 bg-white rounded-2xl border border-stone-200 shadow-sm hover:border-stone-400 transition-all group">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-stone-900">{m.title}</h4>
                    <p className="text-sm text-stone-500 mt-1">{m.content || 'No description provided.'}</p>
                  </div>
                  <a
                    href={m.link}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 bg-stone-50 text-stone-400 group-hover:text-stone-900 group-hover:bg-stone-100 rounded-xl transition-all"
                  >
                    <ExternalLink size={16} />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Job Responsibilities */}
        <section className="space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-stone-100">
            <div className="p-2 bg-stone-100 rounded-xl text-stone-600">
              <Briefcase size={20} />
            </div>
            <h3 className="text-xl font-bold">Job Responsibilities</h3>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {jobs.map((m) => (
              <div key={m.id} className="p-5 bg-white rounded-2xl border border-stone-200 shadow-sm hover:border-stone-400 transition-all group">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-stone-900">{m.title}</h4>
                    <p className="text-sm text-stone-500 mt-1">{m.content || 'No description provided.'}</p>
                  </div>
                  <a
                    href={m.link}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 bg-stone-50 text-stone-400 group-hover:text-stone-900 group-hover:bg-stone-100 rounded-xl transition-all"
                  >
                    <ExternalLink size={16} />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Add Material Modal */}
      {showAdd && (
        <div className="fixed inset-0 bg-stone-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white w-full max-w-md rounded-[32px] shadow-2xl p-8 space-y-6"
          >
            <h3 className="text-2xl font-bold">Add New Material</h3>
            
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-mono text-stone-400 uppercase tracking-wider mb-1 block">Type</label>
                <div className="flex gap-2">
                  <button
                    onClick={() => setNewMaterial({ ...newMaterial, type: 'book' })}
                    className={`flex-1 py-3 rounded-xl text-sm font-bold border transition-all ${
                      newMaterial.type === 'book' ? 'bg-stone-900 text-white border-stone-900' : 'bg-stone-50 border-stone-200 text-stone-500'
                    }`}
                  >
                    Book Reference
                  </button>
                  <button
                    onClick={() => setNewMaterial({ ...newMaterial, type: 'job' })}
                    className={`flex-1 py-3 rounded-xl text-sm font-bold border transition-all ${
                      newMaterial.type === 'job' ? 'bg-stone-900 text-white border-stone-900' : 'bg-stone-50 border-stone-200 text-stone-500'
                    }`}
                  >
                    Job Responsibility
                  </button>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-mono text-stone-400 uppercase tracking-wider mb-1 block">Title</label>
                <input
                  type="text"
                  className="w-full p-4 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-stone-900/10"
                  placeholder="e.g., ASL Grammar Guide"
                  value={newMaterial.title || ''}
                  onChange={(e) => setNewMaterial({ ...newMaterial, title: e.target.value })}
                />
              </div>

              <div>
                <label className="text-[10px] font-mono text-stone-400 uppercase tracking-wider mb-1 block">Link / URL</label>
                <div className="relative">
                  <LinkIcon size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="text"
                    className="w-full p-4 pl-12 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-stone-900/10"
                    placeholder="https://google.sheets/..."
                    value={newMaterial.link || ''}
                    onChange={(e) => setNewMaterial({ ...newMaterial, link: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-mono text-stone-400 uppercase tracking-wider mb-1 block">Description (Optional)</label>
                <textarea
                  className="w-full p-4 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-stone-900/10"
                  rows={3}
                  placeholder="Brief context for the AI..."
                  value={newMaterial.content || ''}
                  onChange={(e) => setNewMaterial({ ...newMaterial, content: e.target.value })}
                />
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                onClick={() => setShowAdd(false)}
                className="flex-1 py-4 bg-stone-100 text-stone-600 rounded-2xl font-bold hover:bg-stone-200 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleAdd}
                className="flex-1 py-4 bg-stone-900 text-white rounded-2xl font-bold hover:bg-stone-800 transition-all shadow-lg shadow-stone-200"
              >
                Add Material
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
