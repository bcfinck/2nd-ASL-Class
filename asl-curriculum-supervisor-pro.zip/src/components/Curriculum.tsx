import { useState } from 'react';
import { CurriculumWeek, Semester } from '../types';
import { motion } from 'motion/react';
import { Sparkles, Save, Edit2, Check } from 'lucide-react';

interface CurriculumProps {
  curriculum: CurriculumWeek[];
  onRefresh: () => void;
  selectedSemester: Semester;
  onSemesterChange: (semester: Semester) => void;
}

export default function Curriculum({ curriculum, onRefresh, selectedSemester, onSemesterChange }: CurriculumProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValues, setEditValues] = useState<Partial<CurriculumWeek>>({});
  const [suggesting, setSuggesting] = useState<string | null>(null);

  const filteredCurriculum = curriculum.filter(w => w.semester === selectedSemester);

  const handleEdit = (week: CurriculumWeek) => {
    setEditingId(week.id);
    setEditValues(week);
  };

  const handleSave = async (id: string) => {
    await fetch(`/api/curriculum/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(editValues),
    });
    setEditingId(null);
    onRefresh();
  };

  const getSuggestion = async (id: string, type: string, currentTopic: string, weekNumber: number) => {
    setSuggesting(`${id}-${type}`);
    try {
      const res = await fetch('/api/ai/suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, weekNumber, currentTopic }),
      });
      const data = await res.json();
      if (data.suggestion) {
        setEditValues(prev => ({
          ...prev,
          [type === 'Book Topic' ? 'bookTopic' : type === 'Job Topic' ? 'jobTopic' : 'homeworkTopic']: data.suggestion
        }));
      }
    } catch (error) {
      console.error('AI Suggestion failed:', error);
    } finally {
      setSuggesting(null);
    }
  };

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-stone-900">Curriculum</h2>
          <p className="text-stone-500 mt-1">Manage weekly topics and assignments for the {selectedSemester} semester.</p>
        </div>
        <div className="flex bg-stone-100 p-1 rounded-2xl border border-stone-200">
          <button
            onClick={() => onSemesterChange('Spring')}
            className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${
              selectedSemester === 'Spring' ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-400 hover:text-stone-600'
            }`}
          >
            Spring
          </button>
          <button
            onClick={() => onSemesterChange('Fall')}
            className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${
              selectedSemester === 'Fall' ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-400 hover:text-stone-600'
            }`}
          >
            Fall
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-4">
        {filteredCurriculum.map((week) => (
          <motion.div
            key={week.id}
            layout
            className={`p-6 bg-white rounded-3xl border transition-all ${
              editingId === week.id ? 'border-stone-900 shadow-xl' : 'border-stone-200 shadow-sm'
            }`}
          >
            <div className="flex justify-between items-start mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-stone-900 text-white rounded-2xl flex items-center justify-center font-bold">
                  {week.weekNumber}
                </div>
                <h3 className="font-bold text-lg">Week {week.weekNumber}</h3>
              </div>
              {editingId === week.id ? (
                <button
                  onClick={() => handleSave(week.id)}
                  className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl text-sm font-bold hover:bg-emerald-700 transition-colors"
                >
                  <Check size={16} /> Save Changes
                </button>
              ) : (
                <button
                  onClick={() => handleEdit(week)}
                  className="flex items-center gap-2 px-4 py-2 bg-stone-100 text-stone-600 rounded-xl text-sm font-bold hover:bg-stone-200 transition-colors"
                >
                  <Edit2 size={16} /> Edit Week
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Book Topic */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-mono text-stone-400 uppercase tracking-wider">Book Topic</label>
                  {editingId === week.id && (
                    <button
                      onClick={() => getSuggestion(week.id, 'Book Topic', editValues.bookTopic || '', week.weekNumber)}
                      disabled={!!suggesting}
                      className="text-stone-400 hover:text-stone-900 transition-colors disabled:opacity-50"
                    >
                      <Sparkles size={14} className={suggesting === `${week.id}-Book Topic` ? 'animate-spin' : ''} />
                    </button>
                  )}
                </div>
                {editingId === week.id ? (
                  <textarea
                    className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-stone-900/10"
                    rows={3}
                    value={editValues.bookTopic}
                    onChange={(e) => setEditValues({ ...editValues, bookTopic: e.target.value })}
                  />
                ) : (
                  <p className="text-sm text-stone-700 leading-relaxed">{week.bookTopic}</p>
                )}
              </div>

              {/* Job Topic */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-mono text-stone-400 uppercase tracking-wider">Job Topic</label>
                  {editingId === week.id && (
                    <button
                      onClick={() => getSuggestion(week.id, 'Job Topic', editValues.jobTopic || '', week.weekNumber)}
                      disabled={!!suggesting}
                      className="text-stone-400 hover:text-stone-900 transition-colors disabled:opacity-50"
                    >
                      <Sparkles size={14} className={suggesting === `${week.id}-Job Topic` ? 'animate-spin' : ''} />
                    </button>
                  )}
                </div>
                {editingId === week.id ? (
                  <textarea
                    className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-stone-900/10"
                    rows={3}
                    value={editValues.jobTopic}
                    onChange={(e) => setEditValues({ ...editValues, jobTopic: e.target.value })}
                  />
                ) : (
                  <p className="text-sm text-stone-700 leading-relaxed">{week.jobTopic}</p>
                )}
              </div>

              {/* Homework */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-mono text-stone-400 uppercase tracking-wider">Homework</label>
                  {editingId === week.id && (
                    <button
                      onClick={() => getSuggestion(week.id, 'Homework', editValues.homeworkTopic || '', week.weekNumber)}
                      disabled={!!suggesting}
                      className="text-stone-400 hover:text-stone-900 transition-colors disabled:opacity-50"
                    >
                      <Sparkles size={14} className={suggesting === `${week.id}-Homework` ? 'animate-spin' : ''} />
                    </button>
                  )}
                </div>
                {editingId === week.id ? (
                  <textarea
                    className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-stone-900/10"
                    rows={3}
                    value={editValues.homeworkTopic}
                    onChange={(e) => setEditValues({ ...editValues, homeworkTopic: e.target.value })}
                  />
                ) : (
                  <p className="text-sm text-stone-700 leading-relaxed">{week.homeworkTopic}</p>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
