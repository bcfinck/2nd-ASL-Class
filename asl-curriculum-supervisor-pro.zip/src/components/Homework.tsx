import { useState } from 'react';
import { HomeworkResponse, Attendee } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, ChevronUp, MessageSquare, Send, AlertCircle } from 'lucide-react';

interface HomeworkProps {
  homework: HomeworkResponse[];
  attendees: Attendee[];
  onRefresh: () => void;
}

export default function Homework({ homework, attendees, onRefresh }: HomeworkProps) {
  const [expandedWeek, setExpandedWeek] = useState<number | null>(null);
  const [selectedResponse, setSelectedResponse] = useState<HomeworkResponse | null>(null);
  const [feedback, setFeedback] = useState('');

  const weeks = Array.from({ length: 16 }, (_, i) => i + 1);

  const getResponsesForWeek = (week: number) => homework.filter(h => h.weekNumber === week);
  const hasUnread = (week: number) => getResponsesForWeek(week).some(h => !h.feedback);

  const handleFeedbackSubmit = async () => {
    if (!selectedResponse) return;
    await fetch(`/api/homework/${selectedResponse.id}/feedback`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ feedback }),
    });
    setFeedback('');
    setSelectedResponse(null);
    onRefresh();
  };

  return (
    <div className="space-y-8">
      <header>
        <h2 className="text-3xl font-bold tracking-tight text-stone-900">Homework Review</h2>
        <p className="text-stone-500 mt-1">Review attendee submissions and provide constructive feedback.</p>
      </header>

      <div className="grid grid-cols-1 gap-4">
        {weeks.map((week) => {
          const responses = getResponsesForWeek(week);
          const isExpanded = expandedWeek === week;
          const unreadCount = responses.filter(r => !r.feedback).length;

          return (
            <div key={week} className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-sm">
              <button
                onClick={() => setExpandedWeek(isExpanded ? null : week)}
                className="w-full p-6 flex items-center justify-between hover:bg-stone-50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-stone-100 rounded-2xl flex items-center justify-center font-bold text-stone-600">
                    {week}
                  </div>
                  <div className="text-left">
                    <h3 className="font-bold">Week {week} Submissions</h3>
                    <p className="text-xs text-stone-400 font-mono uppercase tracking-wider">
                      {responses.length} Responses • {unreadCount} Pending
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  {unreadCount > 0 && (
                    <div className="flex items-center gap-1 px-3 py-1 bg-amber-50 text-amber-600 rounded-full text-[10px] font-bold uppercase tracking-wider border border-amber-100">
                      <AlertCircle size={12} /> Pending Review
                    </div>
                  )}
                  {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                </div>
              </button>

              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: 'auto' }}
                    exit={{ height: 0 }}
                    className="overflow-hidden border-t border-stone-100"
                  >
                    <div className="p-4 space-y-2">
                      {responses.length === 0 ? (
                        <div className="p-8 text-center text-stone-400 text-sm italic">No submissions yet for this week.</div>
                      ) : (
                        responses.map((resp) => (
                          <button
                            key={resp.id}
                            onClick={() => setSelectedResponse(resp)}
                            className={`w-full p-4 flex items-center justify-between rounded-2xl transition-all ${
                              selectedResponse?.id === resp.id ? 'bg-stone-900 text-white' : 'bg-stone-50 hover:bg-stone-100'
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <div className={`w-2 h-2 rounded-full ${resp.feedback ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`} />
                              <span className="font-medium text-sm">{resp.attendeeName}</span>
                            </div>
                            <div className="text-[10px] font-mono opacity-60 uppercase tracking-widest">
                              {new Date(resp.submittedAt).toLocaleDateString()}
                            </div>
                          </button>
                        ))
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>

      {/* Feedback Modal / Panel */}
      <AnimatePresence>
        {selectedResponse && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-stone-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-6"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white w-full max-w-2xl rounded-[32px] shadow-2xl overflow-hidden"
            >
              <div className="p-8 border-b border-stone-100 flex justify-between items-center">
                <div>
                  <h3 className="text-2xl font-bold">{selectedResponse.attendeeName}</h3>
                  <p className="text-stone-500 text-sm">Week {selectedResponse.weekNumber} Submission</p>
                </div>
                <button
                  onClick={() => setSelectedResponse(null)}
                  className="p-2 hover:bg-stone-100 rounded-full transition-colors"
                >
                  <ChevronDown size={24} />
                </button>
              </div>

              <div className="p-8 space-y-8 max-h-[60vh] overflow-y-auto">
                <section>
                  <label className="text-[10px] font-mono text-stone-400 uppercase tracking-wider mb-2 block">Response Content</label>
                  <div className="p-6 bg-stone-50 rounded-2xl text-stone-700 leading-relaxed italic border border-stone-100">
                    "{selectedResponse.response}"
                  </div>
                </section>

                <section>
                  <label className="text-[10px] font-mono text-stone-400 uppercase tracking-wider mb-2 block">Supervisor Feedback</label>
                  {selectedResponse.feedback ? (
                    <div className="p-6 bg-emerald-50 text-emerald-800 rounded-2xl border border-emerald-100">
                      <div className="flex items-center gap-2 mb-2">
                        <MessageSquare size={16} />
                        <span className="font-bold text-sm uppercase tracking-wider font-mono">Feedback Provided</span>
                      </div>
                      <p className="text-sm leading-relaxed">{selectedResponse.feedback}</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <textarea
                        className="w-full p-6 bg-stone-50 border border-stone-200 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-stone-900/10 min-h-[150px]"
                        placeholder="Type your feedback here..."
                        value={feedback}
                        onChange={(e) => setFeedback(e.target.value)}
                      />
                      <button
                        onClick={handleFeedbackSubmit}
                        className="w-full py-4 bg-stone-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-stone-800 transition-all shadow-lg shadow-stone-200"
                      >
                        <Send size={18} /> Submit Feedback
                      </button>
                    </div>
                  )}
                </section>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
