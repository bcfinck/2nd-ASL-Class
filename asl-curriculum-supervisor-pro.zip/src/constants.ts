import { TabType } from './types';
import { LayoutDashboard, BookOpen, ClipboardList, Library, Users } from 'lucide-react';

export const TABS: { id: TabType; icon: any }[] = [
  { id: 'Dashboard', icon: LayoutDashboard },
  { id: 'Curriculum', icon: BookOpen },
  { id: 'Homework', icon: ClipboardList },
  { id: 'Reference Materials', icon: Library },
  { id: 'Class', icon: Users },
];

export const STORE_LOCATIONS = [
  'Midlines',
  'Hardlines',
  'Guns',
  'Softlines',
  'Shoes',
];
