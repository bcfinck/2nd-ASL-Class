/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TABS } from './constants';
import { TabType, Attendee, CurriculumWeek, HomeworkResponse, ReferenceMaterial, Semester } from './types';
import Dashboard from './components/Dashboard';
import Curriculum from './components/Curriculum';
import Homework from './components/Homework';
import ReferenceMaterials from './components/ReferenceMaterials';
import Class from './components/Class';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('Dashboard');
  const [attendees, setAttendees] = useState<Attendee[]>([]);
  const [curriculum, setCurriculum] = useState<CurriculumWeek[]>([]);
  const [homework, setHomework] = useState<HomeworkResponse[]>([]);
  const [materials, setMaterials] = useState<ReferenceMaterial[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSemester, setSelectedSemester] = useState<Semester>('Spring');

  const fetchData = async () => {
    try {
      const [attRes, curRes, hwRes, matRes] = await Promise.all([
        fetch('/api/attendees'),
        fetch('/api/curriculum'),
        fetch('/api/homework'),
        fetch('/api/reference-materials'),
      ]);
      
      setAttendees(await attRes.json());
      setCurriculum(await curRes.json());
      setHomework(await hwRes.json());
      setMaterials(await matRes.json());
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const renderContent = () => {
    switch (activeTab) {
      case 'Dashboard':
        return <Dashboard attendees={attendees} curriculum={curriculum} homework={homework} onRefresh={fetchData} selectedSemester={selectedSemester} />;
      case 'Curriculum':
        return <Curriculum curriculum={curriculum} onRefresh={fetchData} selectedSemester={selectedSemester} onSemesterChange={setSelectedSemester} />;
      case 'Homework':
        return <Homework homework={homework} attendees={attendees} onRefresh={fetchData} />;
      case 'Reference Materials':
        return <ReferenceMaterials materials={materials} onRefresh={fetchData} />;
      case 'Class':
        return <Class attendees={attendees} onRefresh={fetchData} />;
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-stone-50">
        <div className="text-stone-400 font-mono animate-pulse">LOADING CURRICULUM...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 font-sans selection:bg-stone-200">
      {/* Sidebar / Navigation */}
      <nav className="fixed left-0 top-0 h-full w-64 border-r border-stone-200 bg-white p-6 z-10">
        <div className="mb-12">
          <h1 className="text-xl font-bold tracking-tight text-stone-900">ASL Supervisor</h1>
          <p className="text-xs text-stone-400 font-mono mt-1 uppercase tracking-widest">2nd ASL Curriculum</p>
        </div>

        <div className="space-y-2">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                  isActive
                    ? 'bg-stone-900 text-white shadow-lg shadow-stone-200'
                    : 'text-stone-500 hover:bg-stone-100'
                }`}
              >
                <Icon size={20} />
                <span className="text-sm font-medium">{tab.id}</span>
              </button>
            );
          })}
        </div>

        <div className="absolute bottom-8 left-6 right-6">
          <div className="p-4 bg-stone-50 rounded-2xl border border-stone-100">
            <div className="text-[10px] font-mono text-stone-400 uppercase tracking-wider mb-1">System Status</div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-medium text-stone-600">Connected</span>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="ml-64 p-12 max-w-7xl mx-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
