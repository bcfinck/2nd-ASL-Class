export type Semester = 'Spring' | 'Fall';

export interface Attendee {
  id: string;
  name: string;
  rank: number;
  storeLocation: string;
  tenure: string; // e.g., "6 months"
  progress: number; // 0-100
}

export interface CurriculumWeek {
  id: string;
  weekNumber: number;
  semester: Semester;
  bookTopic: string;
  jobTopic: string;
  homeworkTopic: string;
}

export interface HomeworkResponse {
  id: string;
  weekNumber: number;
  attendeeId: string;
  attendeeName?: string; // Joined from attendees table
  response: string;
  feedback: string | null;
  submittedAt: string;
}

export interface ReferenceMaterial {
  id: string;
  type: 'book' | 'job';
  title: string;
  link: string; // URL or description
  content?: string; // For AI context
}

export type TabType = 'Dashboard' | 'Curriculum' | 'Homework' | 'Reference Materials' | 'Class';
