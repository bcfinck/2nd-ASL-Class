import express from 'express';
import { createServer as createViteServer } from 'vite';
import Database from 'better-sqlite3';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database('asl_curriculum.db');

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS attendees (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    rank INTEGER NOT NULL,
    storeLocation TEXT NOT NULL,
    tenure TEXT NOT NULL,
    progress INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS curriculum (
    id TEXT PRIMARY KEY,
    weekNumber INTEGER NOT NULL,
    semester TEXT NOT NULL,
    bookTopic TEXT NOT NULL,
    jobTopic TEXT NOT NULL,
    homeworkTopic TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS homework_responses (
    id TEXT PRIMARY KEY,
    weekNumber INTEGER NOT NULL,
    attendeeId TEXT NOT NULL,
    response TEXT NOT NULL,
    feedback TEXT,
    submittedAt TEXT NOT NULL,
    FOREIGN KEY(attendeeId) REFERENCES attendees(id)
  );

  CREATE TABLE IF NOT EXISTS reference_materials (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    link TEXT NOT NULL,
    content TEXT
  );
`);

// Seed initial data if empty
const curriculumCount = db.prepare('SELECT COUNT(*) as count FROM curriculum').get() as { count: number };
if (curriculumCount.count === 0) {
  const insertAttendee = db.prepare('INSERT INTO attendees (id, name, rank, storeLocation, tenure, progress) VALUES (?, ?, ?, ?, ?, ?)');
  const attendeeCount = db.prepare('SELECT COUNT(*) as count FROM attendees').get() as { count: number };
  if (attendeeCount.count === 0) {
    insertAttendee.run('1', 'Alice Johnson', 1, 'Midlines', '1 year', 85);
    insertAttendee.run('2', 'Bob Smith', 2, 'Hardlines', '6 months', 45);
    insertAttendee.run('3', 'Charlie Brown', 3, 'Softlines', '3 months', 20);
  }

  const insertCurriculum = db.prepare('INSERT INTO curriculum (id, weekNumber, semester, bookTopic, jobTopic, homeworkTopic) VALUES (?, ?, ?, ?, ?, ?)');
  for (let i = 1; i <= 16; i++) {
    insertCurriculum.run(`spring-${i}`, i, 'Spring', `Spring Book Topic ${i}`, `Spring Job Topic ${i}`, `Spring Homework ${i}`);
    insertCurriculum.run(`fall-${i}`, i, 'Fall', `Fall Book Topic ${i}`, `Fall Job Topic ${i}`, `Fall Homework ${i}`);
  }

  const insertMaterial = db.prepare('INSERT INTO reference_materials (id, type, title, link, content) VALUES (?, ?, ?, ?, ?)');
  insertMaterial.run('m1', 'book', 'ASL Basics', 'https://example.com/asl-basics', 'Basic signs and grammar rules for ASL.');
  insertMaterial.run('m2', 'job', 'Customer Service Signs', 'https://example.com/cs-signs', 'Signs specific to retail and customer service.');
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // API Routes
  app.get('/api/attendees', (req, res) => {
    const attendees = db.prepare('SELECT * FROM attendees ORDER BY rank ASC').all();
    res.json(attendees);
  });

  app.post('/api/attendees', (req, res) => {
    const { id, name, rank, storeLocation, tenure, progress } = req.body;
    db.prepare('INSERT INTO attendees (id, name, rank, storeLocation, tenure, progress) VALUES (?, ?, ?, ?, ?, ?)')
      .run(id, name, rank, storeLocation, tenure, progress);
    res.status(201).json({ success: true });
  });

  app.put('/api/attendees/rank', (req, res) => {
    const { ranks } = req.body; // Array of {id, rank}
    const updateRank = db.prepare('UPDATE attendees SET rank = ? WHERE id = ?');
    const transaction = db.transaction((ranks) => {
      for (const item of ranks) updateRank.run(item.rank, item.id);
    });
    transaction(ranks);
    res.json({ success: true });
  });

  app.get('/api/curriculum', (req, res) => {
    const { semester } = req.query;
    let curriculum;
    if (semester) {
      curriculum = db.prepare('SELECT * FROM curriculum WHERE semester = ? ORDER BY weekNumber ASC').all(semester);
    } else {
      curriculum = db.prepare('SELECT * FROM curriculum ORDER BY weekNumber ASC').all();
    }
    res.json(curriculum);
  });

  app.put('/api/curriculum/:id', (req, res) => {
    const { id } = req.params;
    const { bookTopic, jobTopic, homeworkTopic } = req.body;
    db.prepare('UPDATE curriculum SET bookTopic = ?, jobTopic = ?, homeworkTopic = ? WHERE id = ?')
      .run(bookTopic, jobTopic, homeworkTopic, id);
    res.json({ success: true });
  });

  app.get('/api/homework', (req, res) => {
    const responses = db.prepare(`
      SELECT hr.*, a.name as attendeeName 
      FROM homework_responses hr 
      JOIN attendees a ON hr.attendeeId = a.id
      ORDER BY hr.submittedAt DESC
    `).all();
    res.json(responses);
  });

  app.put('/api/homework/:id/feedback', (req, res) => {
    const { id } = req.params;
    const { feedback } = req.body;
    db.prepare('UPDATE homework_responses SET feedback = ? WHERE id = ?').run(feedback, id);
    res.json({ success: true });
  });

  app.get('/api/reference-materials', (req, res) => {
    const materials = db.prepare('SELECT * FROM reference_materials').all();
    res.json(materials);
  });

  app.post('/api/reference-materials', (req, res) => {
    const { id, type, title, link, content } = req.body;
    db.prepare('INSERT INTO reference_materials (id, type, title, link, content) VALUES (?, ?, ?, ?, ?)')
      .run(id, type, title, link, content);
    res.status(201).json({ success: true });
  });

  // Gemini Suggestion Route
  app.post('/api/ai/suggest', async (req, res) => {
    const { type, weekNumber, currentTopic } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return res.status(500).json({ error: 'API Key missing' });

    const ai = new GoogleGenAI({ apiKey });
    const materials = db.prepare('SELECT * FROM reference_materials').all() as any[];
    const context = materials.map(m => `${m.title}: ${m.content}`).join('\n');

    const prompt = `You are an assistant for an ASL Curriculum Supervisor. 
    Based on the following reference materials:
    ${context}
    
    Suggest a ${type} for Week ${weekNumber}. 
    The current topic is: ${currentTopic}.
    Make it relevant to ASL learners in a retail/job environment.
    Provide a concise suggestion (max 2 sentences).`;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      res.json({ suggestion: response.text });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'AI generation failed' });
    }
  });

  // Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
    app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'dist/index.html')));
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
